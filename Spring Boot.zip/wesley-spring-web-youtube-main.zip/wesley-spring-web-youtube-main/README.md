./mvnw spring-boot:start

sudo kill -9 $(lsof -t -i:8080)
