package com.devsuperior.auladomain.entities;

public enum OrderStatus {

	WAITING, PAID, DELIVERED, CANCELED;
}
